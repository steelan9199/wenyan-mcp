#!/usr/bin/env node

/**
 * This is a template MCP server that implements a simple notes system.
 * It demonstrates core MCP concepts like resources and tools by allowing:
 * - Listing notes as resources
 * - Reading individual notes
 * - Creating new notes via a tool
 * - Summarizing all notes via a prompt
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
    CallToolRequestSchema,
    ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { getGzhContent } from "@wenyan-md/core/wrapper";
import { publishToDraft } from "@wenyan-md/core/publish";
import { themes, Theme } from "@wenyan-md/core/theme";
import path from "path";
import fs from "fs";

function normalizePathWithUnderscore(inputPath) {
    // 1. 解码URL编码（处理%20、中文编码等）
    let decodedPath = decodeURIComponent(inputPath);

    // 2. 仅替换非中文、非字母数字、非路径分隔符的特殊字符
    const normalizedPath = decodedPath.replace(
        /([^\u4e00-\u9fa5\w\/\\:\.-])/g,
        "_"
    );

    // 3. 处理文件重命名
    try {
        if (fs.existsSync(decodedPath)) {
            const dir = path.dirname(normalizedPath);
            const ext = path.extname(normalizedPath);
            let filename = path
                .basename(normalizedPath, ext)
                .replace(/^_+|_+$/g, "") // 去除首尾下划线
                .replace(/_+/g, "_"); // 合并连续下划线
            const newPath = path.join(dir, filename + ext);

            if (newPath !== decodedPath) {
                fs.renameSync(decodedPath, newPath);
            }
            return newPath;
        }
        return normalizedPath;
    } catch (err) {
        console.error("处理文件时出错:", err);
        return normalizedPath;
    }
}

/**
 * 将Markdown中的图片相对路径转换为绝对路径（跨平台兼容）
 * @param {string} markdownContent - 原始Markdown内容
 * @param {string} basePath - 基础路径(如图片所在的绝对路径前缀)
 * @returns {string} 处理后的Markdown内容
 */
function convertMdImagePaths(markdownContent, basePath) {
    // 正则表达式匹配Markdown图片语法 ![alt](path)
    const imageRegex = /!\[([^\]]*)\]\(([^)]+)\)/g;

    // 处理每个匹配的图片
    return markdownContent.replace(imageRegex, (match, altText, imgPath) => {
        fs.appendFileSync("D:/github/wenyan-mcp/日志.txt", imgPath + "\n");
        // 如果已经是绝对路径(http/https/file:///或绝对路径)则跳过
        if (/^(https?:|file:|\/)/.test(imgPath)) {
            return `![${altText}](${imgPath})`;
        }

        // 规范化basePath（确保是绝对路径）
        let normalizedBase = path.isAbsolute(basePath)
            ? basePath
            : path.resolve(basePath);

        let resolvedPath = path.resolve(normalizedBase, imgPath);
        // 对于Windows路径，转为正斜杠（Markdown通用）
        let normalizedPath = resolvedPath.split(path.sep).join("/");
        normalizedPath = normalizePathWithUnderscore(normalizedPath);
        const result = `![${altText}](${normalizedPath})`;
        return result;
    });
}
/**
 * Create an MCP server with capabilities for resources (to list/read notes),
 * tools (to create new notes), and prompts (to summarize notes).
 */
const server = new Server(
    {
        name: "wenyan-mcp",
        version: "0.1.0",
    },
    {
        capabilities: {
            resources: {},
            tools: {},
            prompts: {},
            // logging: {},
        },
    }
);

/**
 * Handler that lists available tools.
 * Exposes a single "publish_article" tool that lets clients publish new article.
 */
server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
        tools: [
            {
                name: "publish_article",
                description: "read local file and publish it to '微信公众号'.",
                inputSchema: {
                    type: "object",
                    properties: {
                        content: {
                            type: "string",
                            description: "file path to the article to publish",
                        },
                    },
                    required: ["content"],
                },
            },
            {
                name: "list_themes",
                description:
                    "List the themes compatible with the 'publish_article' tool to publish an article to '微信公众号'.",
                inputSchema: {
                    type: "object",
                    properties: {},
                },
            },
        ],
    };
});

/**
 * Handler for the publish_article tool.
 * Publish a new article with the provided title and content, and returns success message.
 */
server.setRequestHandler(CallToolRequestSchema, async (request) => {
    if (request.params.name === "publish_article") {
        // server.sendLoggingMessage({
        //     level: "debug",
        //     data: JSON.stringify(request.params.arguments),
        // });
        let content = String(request.params.arguments?.content || "");
        // let themeId = String(
        //     request.params.arguments?.theme_id || "orangeheart"
        // );
        let themeId = String("orangeheart");

        let suffix = `\n\n## 扣子智能体教程
https://space.bilibili.com/26079586`;

        let prefix = `---
author: 牙叔教程
title: 请先修改标题和封面
cover: F:/obsidian/obsidian-data-master/01oldData/18image/Snipaste_2025-09-15_21-21-55.jpg
---
本文由AI创作\n\n`;
        const markdownFilePath = content;
        content = fs.readFileSync(content, "utf-8");
        content = convertMdImagePaths(
            content,
            "F:/obsidian/obsidian-data-master"
        );
        fs.writeFileSync(markdownFilePath, content);
        const gzhContent = await getGzhContent(
            [prefix, content, suffix].join(""),
            themeId,
            "solarized-light",
            true,
            false
        );
        const title = gzhContent.title ?? "this is title";
        const cover = gzhContent.cover ?? "";
        const response = await publishToDraft(title, gzhContent.content, cover);

        return {
            content: [
                {
                    type: "text",
                    text: `Your article was successfully published to '公众号草稿箱'. The media ID is ${response.media_id}.`,
                },
            ],
        };
    } else if (request.params.name === "list_themes") {
        const themeResources = Object.entries(themes).map(
            ([id, theme]: [string, Theme]) => ({
                type: "text",
                text: JSON.stringify({
                    id: theme.id,
                    name: theme.name,
                    description: theme.description,
                }),
            })
        );
        return {
            content: themeResources,
        };
    }

    throw new Error("Unknown tool");
});

/**
 * Start the server using stdio transport.
 * This allows the server to communicate via standard input/output streams.
 */
async function main() {
    const transport = new StdioServerTransport();
    await server.connect(transport);
}

main().catch((error) => {
    console.error("Server error:", error);
    process.exit(1);
});
